package raven.analyzer;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;

import raven.analyzer.exception.AnalysisUncheckedException;
import raven.util.EPLConstants;
import raven.util.EPLUtils;

public class Experimenter
{
	public static void createRandomSpecifications(final String path) throws IOException
	{
		final File policyDir = new File(path);
		if (!policyDir.isDirectory())
		{
			throw new AnalysisUncheckedException("Argument is not a dir " + path);
		}

		final File policyFile = new File(path + "FullPolicy.epl_");
		if (!policyFile.exists() || !policyFile.isFile())
		{
			throw new AnalysisUncheckedException("Could not find specification at " + policyFile);
		}

		final Map<String, List<String>> map = PolicyParser.processSpecificationAsMap(policyFile);

		final List<String> rules = map.get(EPLConstants.RULE_DEF_ID);

		final List<String> compartments = map.get(EPLConstants.COMPARTMENT_DEF_ID);

		final StringBuilder compartmentsBuilder = new StringBuilder();
		compartments.stream().forEach(compartmentsBuilder::append);

		final List<String> subRules = new ArrayList<>(rules);

		Collections.sort(subRules);

		final int size = rules.size();
		final Random random = new Random();
		for (int i = size; i >= 0; i--)
		{
			final StringBuilder subRulesBuilder = new StringBuilder(compartmentsBuilder.toString());
			subRules.stream().forEach(subRulesBuilder::append);

			final String newPolicyPath;
			if (i < 10)
			{
				newPolicyPath = String.format("%s0%sPolicy.epl", path, i);
			}
			else
			{
				newPolicyPath = String.format("%s%sPolicy.epl", path, i);
			}

			final String content = subRulesBuilder.toString().replaceAll(";", ";\n");
			EPLUtils.saveToFile(content, newPolicyPath);

			if (i >= 1)
			{
				final int index = random.nextInt(i);
				subRules.remove(index);
			}
		}

	}
}
