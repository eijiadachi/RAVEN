package raven.analyzer;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CatchClause;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.IMethodBinding;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.ThrowStatement;
import org.eclipse.jdt.core.dom.TypeDeclaration;

import raven.analyzer.exception.AnalysisException;
import raven.util.EPLUtils;

public class Counter
{

	public static class CounterVisitor extends ASTVisitor
	{
		public Map<String, Set<String>> throwMap = new HashMap<>();

		public Map<String, Set<String>> catchMap = new HashMap<>();

		private void addToMap(final String packageName, final String raisedExceptionType, final Map<String, Set<String>> map)
		{
			Set<String> list = map.get(packageName);
			if (list == null)
			{
				list = new TreeSet<>();
			}
			list.add(raisedExceptionType);
			map.put(packageName, list);
		}

		private String getPackageName(final ThrowStatement node)
		{
			final TypeDeclaration typeDeclaration = this.getParent(node);
			final String packageName = typeDeclaration.resolveBinding().getPackage().getName();
			return packageName;
		}

		private TypeDeclaration getParent(final ASTNode node)
		{
			ASTNode parent = node.getParent();

			do
			{
				if (parent instanceof TypeDeclaration)
				{
					return (TypeDeclaration) parent;
				}

				parent = parent.getParent();
			}
			while (parent != null);
			return null;
		}

		@Override
		public boolean visit(final CatchClause node)
		{
			final SingleVariableDeclaration exception = node.getException();
			final String exceptionName = exception.resolveBinding().getType().getQualifiedName();
			final TypeDeclaration type = this.getParent(node);
			final String packageName = type.resolveBinding().getPackage().getName();

			this.addToMap(packageName, exceptionName, this.catchMap);

			return true;
		}

		@Override
		public boolean visit(final ThrowStatement node)
		{
			final String packageName = this.getPackageName(node);

			final Expression expression = node.getExpression();
			final ITypeBinding binding = expression.resolveTypeBinding();

			final String raisedExceptionType;

			if (binding == null)
			{
				if (expression instanceof MethodInvocation)
				{
					final MethodInvocation methodInvocation = (MethodInvocation) expression;
					final IMethodBinding methodBinding = methodInvocation.resolveMethodBinding();
					final ITypeBinding returnType = methodBinding.getReturnType();
					raisedExceptionType = returnType.getQualifiedName();
				}
				else
				{

					throw new IllegalStateException("Could not determine exception type");
				}
			}
			else
			{
				raisedExceptionType = binding.getQualifiedName();
			}

			this.addToMap(packageName, raisedExceptionType, this.throwMap);

			return true;
		}
	}

	public static void countMetrics(final String projectName) throws AnalysisException
	{
		try
		{
			final IJavaProject javaProject = EPLUtils.buildJavaProject(projectName);

			final CounterVisitor counterVisitor = new CounterVisitor();

			for (final IPackageFragment mypackage : javaProject.getPackageFragments())
			{

				if (mypackage.getKind() != IPackageFragmentRoot.K_SOURCE)
				{
					continue;
				}

				for (final ICompilationUnit iCompilationUnit : mypackage.getCompilationUnits())
				{

					final CompilationUnit cu = EPLUtils.getCompilationUnit(iCompilationUnit);

					cu.accept(counterVisitor);
				}
			}

			EPLUtils.saveToFile(counterVisitor.catchMap, "/Users/eiji/Downloads/eclipse-rcp-luna/workspace/Examples2/catchMap.txt");
			EPLUtils.saveToFile(counterVisitor.throwMap, "/Users/eiji/Downloads/eclipse-rcp-luna/workspace/Examples2/throwMap.txt");

			//			final Set<Entry<String, Set<String>>> entrySet = counterVisitor.throwMap.entrySet();
			//			for (final Entry<String, Set<String>> entry : entrySet)
			//			{
			//				final String key = entry.getKey();
			//				final Set<String> value = entry.getValue();
			//
			//				System.out.println(String.format("%s\n\t%s", key, value));
			//			}

			System.out.println("Finished.");
		}
		catch (final Exception e)
		{
			e.printStackTrace();
			throw new AnalysisException(e.getMessage(), e);
		}

	}

}
