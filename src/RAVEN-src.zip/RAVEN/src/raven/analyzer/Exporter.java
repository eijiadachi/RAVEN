package raven.analyzer;

import java.io.IOException;

import raven.analyzer.exception.AnalysisException;
import raven.model.CallGraph;
import raven.util.EPLUtils;

public class Exporter
{
	public static void exportCallGraph(final String[] args) throws AnalysisException, IOException
	{
		final String projectName = args[1];

		final CallGraph callGraph = Analyzer.buildCallGraph(projectName);

		final String path = args[3];

		EPLUtils.saveCallGraph(callGraph, path, true);
	}
}
