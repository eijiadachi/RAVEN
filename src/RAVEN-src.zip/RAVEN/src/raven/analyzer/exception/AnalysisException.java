package raven.analyzer.exception;


@SuppressWarnings("serial")
public class AnalysisException extends Exception {

	public AnalysisException(String message, Throwable e) {
		super(message, e);
	}

}
