package raven.analyzer.exception;

@SuppressWarnings("serial")
public class AnalysisUncheckedException extends RuntimeException {

	public AnalysisUncheckedException(final String errorMsg) {
		super(errorMsg);
	}

	public AnalysisUncheckedException(final String errorMsg, final Throwable e) {
		super(errorMsg, e);
	}

	public AnalysisUncheckedException(final Throwable e) {
		super(e);
	}

}
