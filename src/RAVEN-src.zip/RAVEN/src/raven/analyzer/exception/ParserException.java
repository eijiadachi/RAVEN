package raven.analyzer.exception;

public class ParserException extends AnalysisUncheckedException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ParserException(final String errorMsg) {
		super(errorMsg);
	}

	public ParserException(final String errorMsg, final Throwable e) {
		super(errorMsg, e);
	}

	public ParserException(final Throwable e) {
		super(e);
	}

}
