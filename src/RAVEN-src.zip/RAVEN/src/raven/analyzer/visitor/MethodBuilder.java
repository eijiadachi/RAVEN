package raven.analyzer.visitor;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CatchClause;
import org.eclipse.jdt.core.dom.ClassInstanceCreation;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.ConstructorInvocation;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.IMethodBinding;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.IVariableBinding;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.SuperConstructorInvocation;
import org.eclipse.jdt.core.dom.ThrowStatement;

import raven.analyzer.exception.AnalysisUncheckedException;
import raven.model.ExceptionPair;
import raven.model.JavaType;
import raven.model.Method;
import raven.util.EPLUtils;

public class MethodBuilder
{
	public static Method buildMethod(final ClassInstanceCreation node)
	{
		final MethodDeclaration methodDeclaration = getCorrespondingDeclaration(node);
		if (methodDeclaration != null)
		{
			final Method method = buildMethod(methodDeclaration);
			return method;
		}

		// If got here, there is no declaration node --> is API invocation
		final Method method = buildMethod(node.resolveConstructorBinding(), true);

		return method;
	}

	public static Method buildMethod(final ConstructorInvocation node)
	{
		final MethodDeclaration methodDeclaration = getCorrespondingDeclaration(node);
		if (methodDeclaration != null)
		{
			final Method method = buildMethod(methodDeclaration);
			return method;
		}

		// If got here, there is no declaration node --> is API invocation
		final Method method = buildMethod(node.resolveConstructorBinding(), true);

		return method;
	}

	private static Method buildMethod(final IMethodBinding binding, final boolean isApiMethod)
	{
		if (binding != null)
		{
			final Method method = new Method();

			final ITypeBinding declaringClass = binding.getDeclaringClass();
			final String packageName = declaringClass.getPackage().getName();
			final String className = declaringClass.getName();
			final String methodName;
			if (binding.isConstructor())
			{
				methodName = "<init>";
			}
			else
			{
				methodName = binding.getName();
			}

			method.setPackageName(packageName);
			method.setClassName(className);
			method.setName(methodName);

			final ITypeBinding[] parameterTypes = binding.getParameterTypes();
			for (final ITypeBinding iTypeBinding : parameterTypes)
			{
				final String parameterName = iTypeBinding.getQualifiedName();
				method.addParameter(parameterName);
			}

			final ITypeBinding[] exceptionTypes = binding.getExceptionTypes();
			if (isApiMethod && (exceptionTypes == null || exceptionTypes.length == 0))
			{
				// returning null avoids that API methods that don't raise exceptions are inserted in the call graph
				return null;
			}
			for (final ITypeBinding iTypeBinding : exceptionTypes)
			{
				if (isApiMethod)
				{
					//XXX Colocar este detalhe na tese
					method.addExceptionRaised(new JavaType(iTypeBinding.getQualifiedName()));
				}
				else
				{
					method.addExceptionPropagated(new JavaType(iTypeBinding.getQualifiedName()));
				}
			}

			return method;
		}

		throw new AnalysisUncheckedException("Error while building method");

	}

	public static Method buildMethod(final MethodDeclaration node)
	{
		final Method method = buildMethod(node.resolveBinding(), false);

		node.accept(new ASTVisitor()
		{

			private boolean hasVisitedThrow = false;

			@Override
			public void endVisit(final CatchClause node)
			{
				if (!this.hasVisitedThrow)
				{
					method.addExceptionHandled(new JavaType(node.getException().resolveBinding().getType().getQualifiedName()));
				}
				return;
			}

			private boolean useSameVariable(final ThrowStatement node, final CatchClause catchClause)
			{
				final Expression expression = node.getExpression();
				final IVariableBinding varCaughtExceptionBinding = catchClause.getException().resolveBinding();

				return expression instanceof SimpleName && ((SimpleName) expression).resolveBinding() instanceof IVariableBinding && //
						((IVariableBinding) ((SimpleName) expression).resolveBinding()).equals(varCaughtExceptionBinding);
			}

			@Override
			public boolean visit(final CatchClause node)
			{
				this.hasVisitedThrow = false;

				final SingleVariableDeclaration exception = node.getException();
				final ITypeBinding binding = exception.resolveBinding().getType();

				method.addExceptionCaught(new JavaType(binding.getQualifiedName()));

				return true;
			}

			@Override
			public boolean visit(final ThrowStatement node)
			{
				this.hasVisitedThrow = true;

				final ITypeBinding exceptionRaised = node.getExpression().resolveTypeBinding();

				ASTNode parent = node.getParent();
				while (parent != null)
				{
					// ThrowStatement inside catch clause?
					if (parent instanceof CatchClause)
					{
						final CatchClause catchClause = (CatchClause) parent;

						// ThrowStatement uses the same variable caught by the CatchClause?
						if (this.useSameVariable(node, catchClause))
						{
							method.addExceptionRethrown(new JavaType(exceptionRaised.getQualifiedName()));
						}
						else
						{
							final ITypeBinding exceptionCaughtBinding = catchClause.getException().resolveBinding().getType();
							method.addExceptionRemapped(new ExceptionPair(exceptionCaughtBinding, exceptionRaised));
						}
						break;
					}
					parent = parent.getParent();
				}

				// Not inside a catch block
				if (parent == null)
				{
					method.addExceptionRaised(new JavaType(exceptionRaised.getQualifiedName()));
				}

				return true;
			}

		});

		return method;
	}

	public static Method buildMethod(final MethodInvocation node)
	{

		final MethodDeclaration methodDeclaration = getCorrespondingDeclaration(node);
		if (methodDeclaration != null)
		{
			final Method method = buildMethod(methodDeclaration);
			return method;
		}

		// If got here, there is no declaration node --> is API invocation
		final Method method = buildMethod(node.resolveMethodBinding(), true);

		return method;
	}

	public static Method buildMethod(SuperConstructorInvocation node)
	{
		final MethodDeclaration methodDeclaration = getCorrespondingDeclaration(node);
		if (methodDeclaration != null)
		{
			final Method method = buildMethod(methodDeclaration);
			return method;
		}

		// If got here, there is no declaration node --> is API invocation
		final Method method = buildMethod(node.resolveConstructorBinding(), true);

		return method;
	}

	private static MethodDeclaration getCorrespondingDeclaration(final ClassInstanceCreation node)
	{
		final MethodDeclaration declaration = classInstanceCreationMap.get(node);
		if (declaration != null)
		{
			return declaration;
		}

		final IMethodBinding binding = node.resolveConstructorBinding();

		final IJavaElement javaElement = binding.getJavaElement();

		if (javaElement == null)
		{
			return null;
		}

		final ICompilationUnit icu = (ICompilationUnit) javaElement.getAncestor(IJavaElement.COMPILATION_UNIT);

		if (icu == null)
		{
			return null;
		}

		final CompilationUnit compilationUnit = EPLUtils.getCompilationUnit(icu);

		final MethodDeclaration methodDeclaration = (MethodDeclaration) compilationUnit.findDeclaringNode(binding.getKey());

		classInstanceCreationMap.put(node, methodDeclaration);

		return methodDeclaration;
	}

	private static MethodDeclaration getCorrespondingDeclaration(final ConstructorInvocation node)
	{
		final MethodDeclaration declaration = constructorInvocationMap.get(node);
		if (declaration != null)
		{
			return declaration;
		}

		final IMethodBinding binding = node.resolveConstructorBinding();

		final IJavaElement javaElement = binding.getJavaElement();

		if (javaElement == null)
		{
			return null;
		}

		final ICompilationUnit icu = (ICompilationUnit) javaElement.getAncestor(IJavaElement.COMPILATION_UNIT);

		if (icu == null)
		{
			return null;
		}

		final CompilationUnit compilationUnit = EPLUtils.getCompilationUnit(icu);

		final MethodDeclaration methodDeclaration = (MethodDeclaration) compilationUnit.findDeclaringNode(binding.getKey());

		constructorInvocationMap.put(node, methodDeclaration);

		return methodDeclaration;
	}

	private static MethodDeclaration getCorrespondingDeclaration(final MethodInvocation invocationNode)
	{
		final MethodDeclaration declaration = methodInvocationMap.get(invocationNode);
		if (declaration != null)
		{
			return declaration;
		}

		final IMethodBinding binding = (IMethodBinding) invocationNode.getName().resolveBinding();
		final IJavaElement javaElement = binding.getJavaElement();

		if (javaElement == null)
		{
			return null;
		}

		final ICompilationUnit icu = (ICompilationUnit) javaElement.getAncestor(IJavaElement.COMPILATION_UNIT);

		if (icu == null)
		{
			return null;
		}

		final CompilationUnit compilationUnit = EPLUtils.getCompilationUnit(icu);

		final ASTNode declarationNode = compilationUnit.findDeclaringNode(binding.getKey());
		if (!(declarationNode instanceof MethodDeclaration))
		{
			return null;
		}
		final MethodDeclaration methodDeclaration = (MethodDeclaration) declarationNode;

		methodInvocationMap.put(invocationNode, methodDeclaration);

		return methodDeclaration;
	}

	private static MethodDeclaration getCorrespondingDeclaration(SuperConstructorInvocation node)
	{
		final MethodDeclaration declaration = superConstructorInvocationMap.get(node);
		if (declaration != null)
		{
			return declaration;
		}

		final IMethodBinding binding = node.resolveConstructorBinding();

		final IJavaElement javaElement = binding.getJavaElement();

		if (javaElement == null)
		{
			return null;
		}

		final ICompilationUnit icu = (ICompilationUnit) javaElement.getAncestor(IJavaElement.COMPILATION_UNIT);

		if (icu == null)
		{
			return null;
		}

		final CompilationUnit compilationUnit = EPLUtils.getCompilationUnit(icu);

		final MethodDeclaration methodDeclaration = (MethodDeclaration) compilationUnit.findDeclaringNode(binding.getKey());

		superConstructorInvocationMap.put(node, methodDeclaration);

		return methodDeclaration;
	}

	private static final Map<SuperConstructorInvocation, MethodDeclaration> superConstructorInvocationMap = new HashMap<>();

	private static final Map<MethodInvocation, MethodDeclaration> methodInvocationMap = new HashMap<>();

	private static final Map<ConstructorInvocation, MethodDeclaration> constructorInvocationMap = new HashMap<>();

	private static final Map<ClassInstanceCreation, MethodDeclaration> classInstanceCreationMap = new HashMap<>();
}
