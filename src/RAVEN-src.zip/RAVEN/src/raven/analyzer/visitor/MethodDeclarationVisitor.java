package raven.analyzer.visitor;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.BreakStatement;
import org.eclipse.jdt.core.dom.CatchClause;
import org.eclipse.jdt.core.dom.ClassInstanceCreation;
import org.eclipse.jdt.core.dom.ConstructorInvocation;
import org.eclipse.jdt.core.dom.ContinueStatement;
import org.eclipse.jdt.core.dom.DoStatement;
import org.eclipse.jdt.core.dom.EnhancedForStatement;
import org.eclipse.jdt.core.dom.ForStatement;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.SimpleType;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.SuperConstructorInvocation;
import org.eclipse.jdt.core.dom.SwitchStatement;
import org.eclipse.jdt.core.dom.ThrowStatement;
import org.eclipse.jdt.core.dom.TryStatement;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;
import org.eclipse.jdt.core.dom.WhileStatement;

import raven.model.CallGraph;
import raven.model.Method;
import raven.util.EPLConstants;
import raven.util.EPLUtils;

public class MethodDeclarationVisitor extends ASTVisitor
{
	private List<Method> invocations = new ArrayList<Method>();

	private final StringBuilder tokenSequence;

	private final Set<String> vocabulary;

	private final CallGraph graph;

	public MethodDeclarationVisitor(final CallGraph graph)
	{
		this.graph = graph;
		this.tokenSequence = new StringBuilder();
		this.vocabulary = new TreeSet<String>();
	}

	public List<Method> getInvocations()
	{
		return this.invocations;
	}

	public StringBuilder getTokenSequence()
	{
		return this.tokenSequence;
	}

	public Set<String> getVocabulary()
	{
		return this.vocabulary;
	}

	public void setInvocations(final List<Method> invocations)
	{
		this.invocations = invocations;
	}

	@Override
	public boolean visit(final Block node)
	{
		final ASTNode parent = node.getParent();
		if (parent instanceof TryStatement)
		{
			final TryStatement tryStatement = (TryStatement) parent;
			final Block finally1 = tryStatement.getFinally();
			if (finally1 != null && finally1.equals(node))
			{
				this.getTokenSequence().append(EPLConstants.FINALLY_TOKEN);
			}
		}

		return true;
	}

	@Override
	public boolean visit(final BreakStatement node)
	{
		this.getTokenSequence().append(EPLConstants.BREAK_TOKEN);
		return true;
	}

	@Override
	public boolean visit(final CatchClause node)
	{
		this.getTokenSequence().append(EPLConstants.CATCH_TOKEN);
		return true;
	}

	@Override
	public boolean visit(final ClassInstanceCreation node)
	{
		final String fqNameWithParameter = EPLUtils.getFullyQualifiedNameWithParameters(node);

		Method method = this.graph.getMethod(fqNameWithParameter);
		if (method == null)
		{
			method = MethodBuilder.buildMethod(node);
			if (method != null)
			{
				this.graph.addNode(method);
			}
		}

		if (method != null)
		{
			this.getInvocations().add(method);
		}

		return true;
	}

	@Override
	public boolean visit(final ConstructorInvocation node)
	{
		this.getTokenSequence().append(EPLConstants.INVOCATION_TOKEN);

		final String fqNameWithParameter = EPLUtils.getFullyQualifiedNameWithParameters(node);

		Method method = this.graph.getMethod(fqNameWithParameter);
		if (method == null)
		{
			method = MethodBuilder.buildMethod(node);
			if (method != null)
			{
				this.graph.addNode(method);
			}
		}

		if (method != null)
		{
			this.getInvocations().add(method);
		}

		return true;
	}

	@Override
	public boolean visit(final SuperConstructorInvocation node)
	{
		this.getTokenSequence().append(EPLConstants.INVOCATION_TOKEN);

		final String fqNameWithParameter = EPLUtils.getFullyQualifiedNameWithParameters(node);

		Method method = this.graph.getMethod(fqNameWithParameter);
		if (method == null)
		{
			method = MethodBuilder.buildMethod(node);
			if (method != null)
			{
				this.graph.addNode(method);
			}
		}

		if (method != null)
		{
			this.getInvocations().add(method);
		}

		return true;
	}

	@Override
	public boolean visit(final ContinueStatement node)
	{
		this.getTokenSequence().append(EPLConstants.CONTINUE_TOKEN);
		return true;
	}

	@Override
	public boolean visit(final DoStatement node)
	{
		this.getTokenSequence().append(EPLConstants.LOOP_TOKEN);
		return true;
	}

	@Override
	public boolean visit(final EnhancedForStatement node)
	{
		this.getTokenSequence().append(EPLConstants.LOOP_TOKEN);
		return true;
	}

	@Override
	public boolean visit(final ForStatement node)
	{
		this.getTokenSequence().append(EPLConstants.LOOP_TOKEN);
		return true;
	}

	@Override
	public boolean visit(final IfStatement node)
	{
		this.getTokenSequence().append(EPLConstants.DECISION_TOKEN);
		return true;
	}

	@Override
	public boolean visit(final MethodInvocation node)
	{
		this.getTokenSequence().append(EPLConstants.INVOCATION_TOKEN);

		final String fqNameWithParameter = EPLUtils.getFullyQualifiedNameWithParameters(node);

		Method method = this.graph.getMethod(fqNameWithParameter);
		if (method == null)
		{
			method = MethodBuilder.buildMethod(node);
			if (method != null)
			{
				this.graph.addNode(method);
			}
		}

		if (method != null)
		{
			this.getInvocations().add(method);
		}

		return true;
	}

	@Override
	public boolean visit(final SimpleName node)
	{
		final String identifier = node.getIdentifier();
		this.getVocabulary().add(identifier);
		return true;
	}

	@Override
	public boolean visit(final SimpleType node)
	{
		this.getTokenSequence().append(EPLConstants.SIMPLE_TYPE_TOKEN);
		return true;
	}

	@Override
	public boolean visit(final SingleVariableDeclaration node)
	{
		this.getTokenSequence().append(EPLConstants.SINGLE_VARIABLE_TOKEN);
		return true;
	}

	@Override
	public boolean visit(final SwitchStatement node)
	{
		this.getTokenSequence().append(EPLConstants.DECISION_TOKEN);
		return true;
	}

	@Override
	public boolean visit(final ThrowStatement node)
	{
		this.getTokenSequence().append(EPLConstants.THROW_TOKEN);
		return true;
	}

	@Override
	public boolean visit(final TryStatement node)
	{
		this.getTokenSequence().append(EPLConstants.TRY_TOKEN);
		return true;
	}

	@Override
	public boolean visit(final VariableDeclarationStatement node)
	{
		this.getTokenSequence().append(EPLConstants.VARIABLE_DECLARATION_TOKEN);
		return true;
	}

	@Override
	public boolean visit(final WhileStatement node)
	{
		this.getTokenSequence().append(EPLConstants.LOOP_TOKEN);
		return true;
	}
}
