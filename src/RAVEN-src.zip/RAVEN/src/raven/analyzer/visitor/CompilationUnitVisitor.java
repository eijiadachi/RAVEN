package raven.analyzer.visitor;

import java.util.List;
import java.util.Set;

import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.MethodDeclaration;

import raven.model.CallGraph;
import raven.model.Method;
import raven.util.EPLUtils;

public class CompilationUnitVisitor extends ASTVisitor
{

	private final CallGraph graph;

	public CompilationUnitVisitor(final CallGraph graph)
	{
		this.graph = graph;
	}

	@Override
	public boolean visit(final MethodDeclaration node)
	{
		final String fqNameWithParameters = EPLUtils.getFullyQualifiedNameWithParameters(node);
		Method method = this.graph.getMethod(fqNameWithParameters);
		if (method == null)
		{
			method = MethodBuilder.buildMethod(node);
			this.graph.addNode(method);
		}

		final MethodDeclarationVisitor visitor = new MethodDeclarationVisitor(this.graph);

		node.accept(visitor);

		final StringBuilder tokenSequence = visitor.getTokenSequence();
		method.setTokenSequence(tokenSequence);
		final Set<String> vocabulary = visitor.getVocabulary();
		method.setVocabulary(vocabulary);

		final List<Method> invocations = visitor.getInvocations();

		for (final Method invocation : invocations)
		{
			this.graph.addEdge(method, invocation);
		}

		return true;
	}
}
