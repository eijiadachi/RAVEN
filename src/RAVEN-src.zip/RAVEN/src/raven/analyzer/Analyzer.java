package raven.analyzer;

import java.io.File;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.dom.CompilationUnit;

import raven.analyzer.exception.AnalysisException;
import raven.analyzer.exception.AnalysisUncheckedException;
import raven.analyzer.visitor.CompilationUnitVisitor;
import raven.model.CallChain;
import raven.model.CallGraph;
import raven.model.Compartment;
import raven.model.DependencyMatrix;
import raven.model.ExceptionPair;
import raven.model.Method;
import raven.model.Policy;
import raven.model.Recommendation;
import raven.model.RecommendationElement;
import raven.model.Rule.DependencyType;
import raven.util.EPLUtils;

public class Analyzer
{
	public static void analyzeProject(final String[] args)
	{
		System.out.println("Begin analyze project");

		final String projectName = args[1];
		final String policyDirPath = args[2];
		final String callGraphPath = args[3];
		final String methodName = args[4];
		final String expectedException = args[5];

		try
		{
			final File policyDir = new File(policyDirPath);
			if (!policyDir.exists() || !policyDir.isDirectory())
			{
				throw new AnalysisUncheckedException("Argument is not a dir " + policyDirPath);
			}

			final CallGraph callGraph = Analyzer.buildCallGraph(projectName);
			final Method method = callGraph.getMethod(methodName);
			if (method == null)
			{
				final String errorMsg = "Could not load method " + methodName;
				throw new AnalysisUncheckedException(errorMsg);
			}

			final IJavaProject javaProject = EPLUtils.buildJavaProject(projectName);

			System.out.println("Analyzing method " + method);
			final long begin = System.currentTimeMillis();
			System.out.println("Building call chains ");
			final List<CallChain> callChains = callGraph.getCallChains(method);
			System.out.println("Finished call chains " + callChains.size());

			final String[] filesList = policyDir.list();
			for (final String policyFileStr : filesList)
			{
				final String policyFilePath = policyDirPath + policyFileStr;
				final File policyFile = new File(policyFilePath);
				if (policyFile.exists() && policyFile.getAbsolutePath().toLowerCase().endsWith("epl"))
				{
					final Policy policy = PolicyParser.parseSpecification(policyFile);

					final List<Compartment> compartments = policy.getCompartments();
					final Collection<Method> methods = callGraph.getNodes();

					associateMethodsToComparments(compartments, methods);

					final Set<Recommendation> result = new HashSet<>();

					for (final CallChain callChain : callChains)
					{
						final DependencyMatrix matrix = new DependencyMatrix(callChain, callGraph, compartments, javaProject, expectedException);
						final List<Recommendation> recommendations = matrix.getRecommendations();
						result.addAll(recommendations);
					}

					final List<Recommendation> sorted = result.stream().sorted((l1, l2) ->
					{
						return l1.getChangeFactor().compareTo(l2.getChangeFactor());
					}).collect(Collectors.toList());

					final long end = System.currentTimeMillis();

					System.out.println(String.format(" - Time for %s - %s", policyFileStr, (end - begin)));

					final StringBuilder builder = new StringBuilder();

					for (final Recommendation rec : sorted.subList(0, sorted.size() > 2000 ? 2000 : sorted.size()))
					{
						final List<RecommendationElement> recommendationElements = rec.getRecommendationElements();
						final int size = recommendationElements.size();
						for (int i = 0; i < size - 1; i++)
						{
							final RecommendationElement element = recommendationElements.get(i);
							final String str = toProlog(element);
							builder.append(String.format("%s, ", str));
						}
						final RecommendationElement last = recommendationElements.get(size - 1);
						final String str = toProlog(last);
						builder.append(String.format("%s.\n", str));
					}

					EPLUtils.saveToFile(builder, callGraphPath + policyFileStr + ".recs.pl");

					assert compartments.stream().allMatch(comp -> comp.check());
				}
			}
		}
		catch (final Exception e)
		{
			final String error = String.format("Error while processing project: %s\nException message: %s", projectName, e.getMessage());
			System.err.println(error);
			throw new AnalysisUncheckedException(e);
		}
		finally
		{
			System.out.println("Finished analyze project");
		}
	}

	private static void associateMethodsToComparments(final List<Compartment> compartments, final Collection<Method> methods)
	{
		for (final Compartment compartment : compartments)
		{
			final List<String> expressions = compartment.getExpressions();

			for (final String expression : expressions)
			{
				final Pattern pattern = Pattern.compile(expression);

				for (final Method method : methods)
				{
					final String fullyQualifiedName = method.getFullyQualifiedName();

					if (pattern.matcher(fullyQualifiedName).find())
					{
						compartment.addMethod(method);
						method.setCompartment(compartment);
					}
				}
			}
		}

		assert compartments.stream().allMatch(comp -> comp.check());
	}

	public static CallGraph buildCallGraph(final String projectName) throws AnalysisException
	{
		System.out.println("Building call graph.");
		try
		{
			final IJavaProject javaProject = EPLUtils.buildJavaProject(projectName);

			System.out.println("Analyzing " + projectName);

			final CallGraph graph = new CallGraph();

			for (final IPackageFragment mypackage : javaProject.getPackageFragments())
			{

				if (mypackage.getKind() != IPackageFragmentRoot.K_SOURCE)
				{
					continue;
				}

				//				if (!mypackage.getElementName().contains("task"))
				//				{
				//					continue;
				//				}

				for (final ICompilationUnit iCompilationUnit : mypackage.getCompilationUnits())
				{

					final CompilationUnit cu = EPLUtils.getCompilationUnit(iCompilationUnit);

					final CompilationUnitVisitor compilationUnitVisitor = new CompilationUnitVisitor(graph);

					cu.accept(compilationUnitVisitor);
				}
			}

			System.out.println("Finished call graph.");

			return graph;
		}
		catch (final Exception e)
		{
			throw new AnalysisException(e.getMessage(), e);
		}
	}

	private static String toProlog(final RecommendationElement element)
	{
		final String str;
		final DependencyType dependencyType = element.getDependencyType();
		final Method m = element.getMethod();
		final Object exception = element.getException();
		if (DependencyType.Remap.equals(dependencyType))
		{
			final ExceptionPair pair = (ExceptionPair) exception;
			str = String.format("%s('%s', '%s', '%s')", dependencyType.toString().toLowerCase(), m, pair.getFrom(), pair.getTo());
		}
		else
		{
			str = String.format("%s('%s', '%s')", dependencyType.toString().toLowerCase(), m, exception);
		}
		return str;
	}

}
