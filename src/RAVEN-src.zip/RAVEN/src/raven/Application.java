package raven;

import org.eclipse.equinox.app.IApplication;
import org.eclipse.equinox.app.IApplicationContext;

import raven.util.EPLConstants;

/**
 * This class controls all aspects of the application's execution
 */
public class Application implements IApplication
{
	private void execute(final String[] args) throws Exception
	{
		System.out.println("Running EPL");

		//		eplrh.analyzer.Exporter.exportCallGraph(args);
		raven.analyzer.Analyzer.analyzeProject(args);
		//		Experimenter.createRandomSpecifications(args[2]);
	}

	@Override
	public Object start(final IApplicationContext context) throws Exception
	{
		final String[] args = (String[]) context.getArguments().get(EPLConstants.APP_ARGS_KEY);

		System.out.println("Start");
		final long begin = System.currentTimeMillis();
		this.execute(args);
		final long end = System.currentTimeMillis();

		System.out.println(String.format("End.\nTotal Running Time: %s ms", (end - begin)));

		return IApplication.EXIT_OK;
	}

	@Override
	public void stop()
	{
		// nothing to do
	}
}
