package raven.util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ClassInstanceCreation;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.ConstructorInvocation;
import org.eclipse.jdt.core.dom.IMethodBinding;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.SuperConstructorInvocation;

import raven.model.CallGraph;
import raven.model.ExceptionPair;
import raven.model.JavaType;
import raven.model.Method;
import raven.model.Rule.DependencyType;

public class EPLUtils
{
	private static void appendExceptions(final List<String> list2, final List<JavaType> list, final DependencyType type, final String methodName)
	{
		for (final JavaType e : list)
		{
			final String str = String.format(REGULAR_FORMAT, type.toString().toLowerCase(), methodName, e);
			list2.add(str);
		}
	}

	private static void appendPairs(final List<String> list2, final List<ExceptionPair> list, final DependencyType remap, final String methodName)
	{
		for (final ExceptionPair e : list)
		{
			final String str = String.format(REMAP_FORMAT, DependencyType.Remap.toString().toLowerCase(), methodName, e.getFrom(), e.getTo());
			list2.add(str);
		}

	}

	public static IJavaProject buildJavaProject(final String projectName) throws JavaModelException
	{
		final IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		final IProject project = root.getProject(projectName);
		final IJavaProject javaProject = JavaCore.create(project);
		javaProject.open(null);
		return javaProject;
	}

	private static ASTParser createASTParser(final ICompilationUnit iCompilationUnit)
	{
		final ASTParser parser = ASTParser.newParser(AST.JLS8);
		parser.setKind(ASTParser.K_COMPILATION_UNIT);
		parser.setResolveBindings(true);
		parser.setBindingsRecovery(true);
		parser.setSource(iCompilationUnit);
		return parser;
	}

	private static String getCommonLongestSubsequence(final String a, final String b)
	{
		final int[][] lengths = new int[a.length() + 1][b.length() + 1];

		// row 0 and column 0 are initialized to 0 already
		for (int i = 0; i < a.length(); i++)
		{
			for (int j = 0; j < b.length(); j++)
			{
				if (a.charAt(i) == b.charAt(j))
				{
					lengths[i + 1][j + 1] = lengths[i][j] + 1;
				}
				else
				{
					lengths[i + 1][j + 1] = lengths[i + 1][j] >= lengths[i][j + 1] ? lengths[i + 1][j] : lengths[i][j + 1];
				}
			}
		}

		// read the substring out from the matrix
		final StringBuffer sb = new StringBuffer();
		for (int x = a.length(), y = b.length(); x != 0 && y != 0;)
		{
			if (lengths[x][y] == lengths[x - 1][y])
			{
				x--;
			}
			else if (lengths[x][y] == lengths[x][y - 1])
			{
				y--;
			}
			else
			{
				assert a.charAt(x - 1) == b.charAt(y - 1);
				sb.append(a.charAt(x - 1));
				x--;
				y--;
			}
		}

		return sb.reverse().toString();
	}

	public static CompilationUnit getCompilationUnit(final ICompilationUnit iCompilationUnit)
	{
		final CompilationUnit compilationUnit = compilationUnitMap.get(iCompilationUnit);
		if (compilationUnit != null)
		{
			return compilationUnit;
		}

		final ASTParser parser = createASTParser(iCompilationUnit);
		final CompilationUnit cu = (CompilationUnit) parser.createAST(null);

		compilationUnitMap.put(iCompilationUnit, cu);

		return cu;
	}

	private static String getFullyQualifiedName(final ClassInstanceCreation node)
	{
		final IMethodBinding binding = node.resolveConstructorBinding();
		if (binding == null)
		{
			final ITypeBinding typeBinding = node.getType().resolveBinding();
			final String name;
			if (typeBinding != null)
			{
				name = String.format("%s.<init>", typeBinding.getQualifiedName());
			}
			else
			{
				name = "<init>";
			}
			return name;
		}

		final String fullyQualifiedName = getFullyQualifiedName(binding);

		return fullyQualifiedName;
	}

	private static String getFullyQualifiedName(final ConstructorInvocation node)
	{
		final IMethodBinding binding = node.resolveConstructorBinding();
		if (null == binding)
		{
			final String name = "<init>";
			return name;
		}
		final String fullyQualifiedName = getFullyQualifiedName(binding);

		return fullyQualifiedName;
	}

	private static String getFullyQualifiedName(final IMethodBinding binding)
	{
		final String key = binding.getKey();
		final String qualifiedName = qualifiedNameMap.get(key);
		if (qualifiedName != null)
		{
			return qualifiedName;
		}

		final ITypeBinding declaringClass = binding.getDeclaringClass();
		final String packageName = declaringClass.getPackage().getName();
		final String className = declaringClass.getName();
		final String methodName;
		if (binding.isConstructor())
		{
			methodName = "<init>";
		}
		else
		{
			methodName = binding.getName();
		}

		final String methodQualifiedName = String.format(EPLConstants.METHOD_FULLY_QUALIFIED_NAME_FORMAT, packageName, className, methodName);

		qualifiedNameMap.put(key, methodQualifiedName);

		return methodQualifiedName;
	}

	private static String getFullyQualifiedName(final MethodDeclaration node)
	{
		final IMethodBinding binding = node.resolveBinding();
		if (null == binding)
		{
			return node.getName().getFullyQualifiedName();
		}
		final String fullyQualifiedname = getFullyQualifiedName(binding);
		return fullyQualifiedname;
	}

	private static String getFullyQualifiedName(final MethodInvocation node)
	{
		final IMethodBinding binding = node.resolveMethodBinding();
		if (null == binding)
		{
			final String fullyQualifiedName = node.getName().getFullyQualifiedName();
			return fullyQualifiedName;
		}

		final String fullyQualifiedName = getFullyQualifiedName(binding);
		return fullyQualifiedName;
	}

	private static String getFullyQualifiedName(SuperConstructorInvocation node)
	{
		final IMethodBinding binding = node.resolveConstructorBinding();
		if (null == binding)
		{
			final String name = "<init>";
			return name;
		}
		final String fullyQualifiedName = getFullyQualifiedName(binding);

		return fullyQualifiedName;
	}

	public static String getFullyQualifiedNameWithParameters(final ClassInstanceCreation node)
	{
		final String fqNameWithParam = classInstanceWithParametersMap.get(node);
		if (fqNameWithParam != null)
		{
			return fqNameWithParam;
		}

		final String fqName = getFullyQualifiedName(node);

		final IMethodBinding binding = node.resolveConstructorBinding();

		final ITypeBinding[] parameterTypes = binding.getParameterTypes();

		final String fqNameWithParameters = getFullyQualifiedNameWithParameters(fqName, parameterTypes);

		classInstanceWithParametersMap.put(node, fqNameWithParameters);

		return fqNameWithParameters;
	}

	public static String getFullyQualifiedNameWithParameters(final ConstructorInvocation node)
	{
		final String fqNameWithParam = constructorInvocationWithParametersMap.get(node);
		if (fqNameWithParam != null)
		{
			return fqNameWithParam;
		}

		final String fqName = getFullyQualifiedName(node);

		final ITypeBinding[] parameterTypes = node.resolveConstructorBinding().getParameterTypes();

		final String fqNameWithParameters = getFullyQualifiedNameWithParameters(fqName, parameterTypes);

		constructorInvocationWithParametersMap.put(node, fqNameWithParameters);

		return fqNameWithParameters;
	}

	public static String getFullyQualifiedNameWithParameters(final MethodDeclaration node)
	{
		final String fqName = getFullyQualifiedName(node);

		final IMethodBinding binding = node.resolveBinding();
		final ITypeBinding[] parameterTypes = binding.getParameterTypes();

		final String fqNameWithParameters = getFullyQualifiedNameWithParameters(fqName, parameterTypes);

		return fqNameWithParameters;
	}

	public static String getFullyQualifiedNameWithParameters(final MethodInvocation node)
	{
		final String fqNameWithParam = methodInvocationWithParametersMap.get(node);
		if (fqNameWithParam != null)
		{
			return fqNameWithParam;
		}

		final String fqName = getFullyQualifiedName(node);

		final ITypeBinding[] parameterTypes = node.resolveMethodBinding().getParameterTypes();

		final String fqNameWithParameters = getFullyQualifiedNameWithParameters(fqName, parameterTypes);

		methodInvocationWithParametersMap.put(node, fqNameWithParameters);

		methodInvocationWithParametersMap.put(node, fqNameWithParameters);

		return fqNameWithParameters;
	}

	private static String getFullyQualifiedNameWithParameters(final String fullyQualifiedName, final ITypeBinding[] parameterTypes)
	{
		final List<String> names = new ArrayList<String>();

		Arrays.asList(parameterTypes).stream().forEach(type -> names.add(type.getQualifiedName()));

		final String fqNameWithParameters = String.format(EPLConstants.METHOD_NAME_WITH_PARAMETER_FORMAT, fullyQualifiedName, names);

		return fqNameWithParameters;
	}

	public static String getFullyQualifiedNameWithParameters(SuperConstructorInvocation node)
	{
		final String fqNameWithParam = superConstructorInvocationWithParametersMap.get(node);
		if (fqNameWithParam != null)
		{
			return fqNameWithParam;
		}

		final String fqName = getFullyQualifiedName(node);

		final ITypeBinding[] parameterTypes = node.resolveConstructorBinding().getParameterTypes();

		final String fqNameWithParameters = getFullyQualifiedNameWithParameters(fqName, parameterTypes);

		superConstructorInvocationWithParametersMap.put(node, fqNameWithParameters);

		return fqNameWithParameters;
	}

	private static Double getMethodNameSimilarity(final Method method1, final Method method2)
	{
		final String fullyQualifiedNameWithParameters = method1.getFullyQualifiedNameWithParameters();
		final String fullyQualifiedNameWithParameters2 = method2.getFullyQualifiedNameWithParameters();
		final Double similarity = fullyQualifiedNameWithParameters.equalsIgnoreCase(fullyQualifiedNameWithParameters2) ? 1.0 : 0.0;
		return similarity;
	}

	public static Double getSimilarity(final Method method1, final Method method2)
	{
		final Double structuralSimilarity = getStructuralSimilarity(method1, method2);
		final Double vocabularySimilarity = getVocabularySimilarity(method1, method2);
		final Double methodNameSimilarity = getMethodNameSimilarity(method1, method2);

		return structuralSimilarity + vocabularySimilarity + methodNameSimilarity;
	}

	private static Double getStructuralSimilarity(final Method method1, final Method method2)
	{
		final StringBuilder tokenSequence1 = method1.getTokenSequence();
		final StringBuilder tokenSequence2 = method2.getTokenSequence();
		final String cls = EPLUtils.getCommonLongestSubsequence(tokenSequence1.toString(), tokenSequence2.toString());

		final Double similarity = Math.min(((double) cls.length() / tokenSequence1.length()), ((double) cls.length() / tokenSequence2.length()));

		if (similarity.isNaN())
		{
			return new Double(0.0);
		}

		return similarity;
	}

	private static Double getVocabularySimilarity(final Method method1, final Method method2)
	{
		final Set<String> vocabulary1 = method1.getVocabulary();
		final int size1 = vocabulary1.size();
		final Set<String> vocabulary2 = method2.getVocabulary();
		final int size2 = vocabulary2.size();

		final Set<String> smaller = size1 <= size2 ? vocabulary1 : vocabulary2;
		final Set<String> larger = size1 > size2 ? vocabulary1 : vocabulary2;

		final Set<String> intersection = new HashSet<String>(smaller);
		intersection.retainAll(larger);
		final Set<String> union = new HashSet<String>(size1 + size2);
		union.addAll(vocabulary1);
		union.addAll(vocabulary2);

		final Double similarity = (double) intersection.size() / (double) union.size();

		if (similarity.isNaN())
		{
			return new Double(0.0);
		}

		return similarity;
	}

	public static <T> List<T> randomSublistt(final List<T> list, final int size)
	{
		assert size <= list.size() : "Size argument is bigger than the size of the list.";

		Collections.shuffle(list);

		return new ArrayList<T>(list.subList(0, size));
	}

	public static CallGraph readCallGraph(final String path) throws ClassNotFoundException, IOException
	{
		final String cgFilePath = path + "call-graph.cg";
		final CallGraph callGraph = (CallGraph) readFromStream(cgFilePath);
		return callGraph;
	}

	public static Object readFromStream(final String path) throws IOException, ClassNotFoundException
	{
		try (final ObjectInputStream stream = new ObjectInputStream(new FileInputStream(path)))
		{
			final Object obj = stream.readObject();
			return obj;
		}
	}

	public static void saveCallGraph(final CallGraph callGraph, final String path, final boolean savePrologRepresentation) throws IOException
	{
		final String cgFilePath = path + "call-graph.cg";

		// Saves the object
		EPLUtils.saveToStream(callGraph, cgFilePath);

		// Saves as Prolog facts
		if (savePrologRepresentation)
		{
			final List<Method> nodes = callGraph.getNodes();

			final List<String> list = new ArrayList<>();

			for (final Method method : nodes)
			{
				final String methodName = method.getFullyQualifiedNameWithParameters();

				appendExceptions(list, method.getExceptionsHandled(), DependencyType.Handle, methodName);
				appendExceptions(list, method.getExceptionsPropagated(), DependencyType.Propagate, methodName);
				appendExceptions(list, method.getExceptionsRaised(), DependencyType.Raise, methodName);
				appendExceptions(list, method.getExceptionsRethrown(), DependencyType.Rethrow, methodName);
				appendPairs(list, method.getExceptionsRemapped(), DependencyType.Remap, methodName);
			}

			Collections.sort(list);

			final StringBuilder builder = new StringBuilder();
			for (final String string : list)
			{
				builder.append(string);
			}

			EPLUtils.saveToFile(builder, cgFilePath + ".pl");
		}

	}

	public static void saveToFile(final Object o, final String path) throws IOException
	{
		try (final FileWriter writer = new FileWriter(path))
		{
			writer.write(o.toString());
		}
	}

	public static void saveToStream(final Object o, final String path) throws IOException
	{
		try (final ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream(path)))
		{
			stream.writeObject(o);
		}
	}

	private static final Map<SuperConstructorInvocation, String> superConstructorInvocationWithParametersMap = new HashMap<>();

	private static Map<String, String> qualifiedNameMap = new HashMap<>();

	private static Map<ICompilationUnit, CompilationUnit> compilationUnitMap = new HashMap<>();

	private static final Map<ClassInstanceCreation, String> classInstanceWithParametersMap = new HashMap<>();

	private static final Map<ConstructorInvocation, String> constructorInvocationWithParametersMap = new HashMap<>();

	private static final Map<MethodInvocation, String> methodInvocationWithParametersMap = new HashMap<>();

	private static final String REGULAR_FORMAT = "%s('%s', '%s').\n";

	private static final String REMAP_FORMAT = "%s('%s', '%s', '%s').\n";
}
