package raven.model;

import raven.model.Rule.DependencyType;

public class RecommendationElement
{
	private Method method;

	private DependencyType dependencyType;

	private Object exception;

	private RecommendationElement()
	{
		super();
	}

	public RecommendationElement(final Method method, final DependencyType dependencyType, final Object exception)
	{
		this.setDependencyType(dependencyType);
		this.setException(exception);
		this.setMethod(method);
	}

	@Override
	public RecommendationElement clone()
	{
		final RecommendationElement element = new RecommendationElement();
		element.setDependencyType(this.getDependencyType());
		element.setException(this.getException());
		element.setMethod(this.getMethod());
		return element;
	}

	@Override
	public boolean equals(final Object obj)
	{
		final RecommendationElement e = (RecommendationElement) obj;
		final boolean depTypeEquals = this.dependencyType.equals(e.getDependencyType());
		final boolean exceptionEquals = this.exception.equals(e.getException());
		final boolean methodEquals = this.method.equals(e.getMethod());
		return depTypeEquals && exceptionEquals && methodEquals;
	}

	public DependencyType getDependencyType()
	{
		return this.dependencyType;
	}

	public Object getException()
	{
		return this.exception;
	}

	public Method getMethod()
	{
		return this.method;
	}

	private void setDependencyType(final DependencyType dependencyType)
	{
		this.dependencyType = dependencyType;
	}

	private void setException(final Object exception)
	{
		this.exception = exception;
	}

	private void setMethod(final Method method)
	{
		this.method = method;
	}

	@Override
	public String toString()
	{
		final String format = String.format("%s %s %s", this.method, this.dependencyType, this.exception);
		return format;
	}
}
