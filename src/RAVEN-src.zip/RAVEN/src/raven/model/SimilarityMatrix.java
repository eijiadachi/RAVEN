package raven.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import raven.util.EPLUtils;

public class SimilarityMatrix
{
	/**
	 * Map that stores for each method the list of similar methods.
	 */
	private static final Map<Method, List<Method>> similarListMap = new HashMap<>();

	/**
	 * Map that stores for pairs of methods the similarity value between them.
	 */
	private static final Map<Method, Map<Method, Double>> similarityValueMap = new HashMap<>();

	private final CallGraph callGraph;

	public SimilarityMatrix(final CallGraph callGraph)
	{
		this.callGraph = callGraph;
	}

	/**
	 * For a given 'method', finds the n most similar methods in 'list'.
	 */
	private List<Method> getNSimilar(final List<Method> list, final Method method, final int n)
	{
		// This is a critical method. Avoided calling auxiliary methods to improve performance.
		int left = 1;
		int right = list.size() - 1;

		//map to store similarity between methods and avoid recalculating
		Map<Method, Double> map = similarityValueMap.get(method);
		if (map == null)
		{
			map = new HashMap<>();
			similarityValueMap.put(method, map);
		}

		// Uses the partition algorithm form quicksort to split the list around the n-th most similar method.
		while (true)
		{
			final int initialLeft = left;
			final int initialRight = right;

			final int pivotIndex = left - 1;
			final Method pivot = list.get(pivotIndex);

			Double sPivot = map.get(pivot);
			if (sPivot == null)
			{
				sPivot = EPLUtils.getSimilarity(method, pivot);
				map.put(pivot, sPivot);
			}

			do
			{
				Method mLeft = list.get(left);
				Double sLeft = map.get(mLeft);
				if (sLeft == null)
				{
					sLeft = EPLUtils.getSimilarity(method, mLeft);
					map.put(mLeft, sLeft);
				}

				Method mRight = list.get(right);
				Double sRight = map.get(mRight);
				if (sRight == null)
				{
					sRight = EPLUtils.getSimilarity(method, mRight);
					map.put(mRight, sRight);
				}

				// partition
				// elements more similar to 'method' are placed on the left of the pivot
				// elements less similar to 'method' are placed on the right of the pivot
				while (sLeft > sPivot && left < right)
				{
					left++;
					mLeft = list.get(left);
					sLeft = map.get(mLeft);
					if (sLeft == null)
					{
						sLeft = EPLUtils.getSimilarity(method, mLeft);
						map.put(mLeft, sLeft);
					}
				}

				while (sRight < sPivot && left < right)
				{
					right--;
					mRight = list.get(right);
					sRight = map.get(mRight);
					if (sRight == null)
					{
						sRight = EPLUtils.getSimilarity(method, mRight);
						map.put(mRight, sRight);
					}
				}

				if (left < right)
				{
					list.set(left, list.set(right, list.get(left)));
					left++;
					right--;
				}
			}
			while (left < right);

			// places pivot in its right position
			list.set(pivotIndex, list.set(left - 1, list.get(pivotIndex)));

			if (n == left - 1)
			{
				final List<Method> subList = list.subList(0, n);

				assert subList.stream().allMatch(e -> EPLUtils.getSimilarity(method, e) >= EPLUtils.getSimilarity(method, list.get(n)));

				return subList;
			}
			// redefine upper and bottom limits
			else if (n < left - 1)
			{
				left = initialLeft;
				right--;
			}
			else
			{
				right = initialRight;
				left++;
			}
		}//end do-while
	}//end while

	public List<Method> getSimilarMethods(final Method method)
	{
		final List<Method> similarMethods = new ArrayList<Method>(this.callGraph.getNodes());

		similarMethods.remove(method);

		List<Method> result = similarListMap.get(method);
		if (result == null)
		{
			result = this.getNSimilar(similarMethods, method, 100);
			similarListMap.put(method, result);
		}

		return result;
	}
}
