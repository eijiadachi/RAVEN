package raven.model;

import java.util.List;

public interface ICallGraphAccessor {
	public List<Method> getWorkingSet(CallGraph callGraph, Method method);
}
