package raven.model;

import java.util.ArrayList;
import java.util.List;

import raven.model.Rule.DependencyType;

public class Recommendation
{
	private List<RecommendationElement> recommendationElements;

	private int changeImpact;

	public Recommendation()
	{
		this.setRecommendations(new ArrayList<RecommendationElement>());
		this.setChangeImpact(-1);
	}

	public Recommendation(final Recommendation solution)
	{
		final List<RecommendationElement> elements = new ArrayList<>();
		for (final RecommendationElement element : solution.getRecommendationElements())
		{
			final RecommendationElement clone = element.clone();
			elements.add(clone);
		}

		this.setRecommendations(elements);
	}

	public void addRecommendationElement(final RecommendationElement element)
	{
		this.getRecommendationElements().add(element);
	}

	public void clear()
	{
		this.getRecommendationElements().clear();
	}

	@Override
	public Recommendation clone()
	{
		final Recommendation recommendationClone = new Recommendation();
		for (final RecommendationElement element : this.getRecommendationElements())
		{
			final RecommendationElement elementClone = element.clone();
			recommendationClone.addRecommendationElement(elementClone);
		}
		return recommendationClone;
	}

	public void computeChangeImpact(final CallGraph callGraph)
	{
		int cont = 0;
		for (final RecommendationElement element : this.getRecommendationElements())
		{
			final Method method = callGraph.getMethod(element.getMethod().getFullyQualifiedNameWithParameters());
			final DependencyType dependencyType = element.getDependencyType();
			final Object exception = element.getException();
			switch (dependencyType)
			{
				case Handle:
				{
					final List<JavaType> exceptionsHandled = method.getExceptionsHandled();
					if (!exceptionsHandled.contains(exception))
					{
						cont++;
					}
					break;
				}

				case Raise:
				{
					final List<JavaType> exceptionsRaised = method.getExceptionsRaised();
					if (!exceptionsRaised.contains(exception))
					{
						cont++;
					}
					break;
				}

				case Propagate:
				{
					final List<JavaType> exceptionsPropagated = method.getExceptionsPropagated();
					if (!exceptionsPropagated.contains(exception))
					{
						cont++;
					}
					break;
				}

				case Rethrow:
				{
					final List<JavaType> exceptionsRethrown = method.getExceptionsRethrown();
					if (!exceptionsRethrown.contains(exception))
					{
						cont++;
					}
					break;
				}

				case Remap:
				{
					final List<ExceptionPair> exceptionsRemapped = method.getExceptionsRemapped();
					if (!exceptionsRemapped.contains(exception))
					{
						cont++;
					}
					break;
				}
				default:
					break;
			}
		}

		this.setChangeImpact(cont);

	}

	@Override
	public boolean equals(final Object obj)
	{
		final Recommendation rec = (Recommendation) obj;
		final boolean isEquals = this.recommendationElements.equals(rec.getRecommendationElements());
		return isEquals;
	}

	public Float getChangeFactor()
	{
		return (float) this.getChangeImpact() / this.size();
	}

	public int getChangeImpact()
	{
		return this.changeImpact;
	}

	public List<RecommendationElement> getRecommendationElements()
	{
		return this.recommendationElements;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		final int result = prime * +this.toString().hashCode();
		return result;
	}

	public boolean isEmpty()
	{
		return this.getRecommendationElements().isEmpty();
	}

	public void pop()
	{
		if (this.getRecommendationElements().size() > 0)
		{
			this.getRecommendationElements().remove(this.getRecommendationElements().size() - 1);
		}
	}

	public void remove(final int i)
	{
		this.getRecommendationElements().remove(i);
	}

	public void setChangeImpact(final int changeImpact)
	{
		this.changeImpact = changeImpact;
	}

	private void setRecommendations(final List<RecommendationElement> recommendations)
	{
		this.recommendationElements = recommendations;
	}

	public int size()
	{
		return this.getRecommendationElements().size();
	}

	@Override
	public String toString()
	{
		final StringBuilder builder = new StringBuilder();

		for (final RecommendationElement element : this.getRecommendationElements())
		{
			final String format = String.format("%s %s %s\n", element.getMethod(), element.getDependencyType(), element.getException());
			builder.append(format);
		}
		builder.append(String.format("%s %s %s ", this.getChangeImpact(), this.size(), this.getChangeFactor()));
		return builder.toString();
	}
}
