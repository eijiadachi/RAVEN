package raven.model;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class CallChain
{
	private final LinkedList<Method> methods;

	private final Map<Method, Integer> positions;

	public CallChain()
	{
		this.methods = new LinkedList<Method>();
		this.positions = new HashMap<Method, Integer>();
	}

	public void add(final Method method)
	{
		this.getMethods().add(method);
		this.getPositions().put(method, this.getMethods().size() - 1);
	}

	public void addAll(final List<Method> methods)
	{
		for (final Method method : methods)
		{
			this.add(method);
		}
	}

	public boolean check()
	{
		if (!this.getMethods().isEmpty())
		{
			assert this.getFirst().equals(this.getMethods().get(0));
			assert this.getLast().equals(this.getMethods().get(this.getMethods().size() - 1));
		}
		for (final Entry<Method, Integer> entry : this.getPositions().entrySet())
		{
			final Method m = entry.getKey();
			assert this.getMethods().contains(m);
			final Integer position = entry.getValue();
			assert position >= 0 && position < this.getMethods().size();
			assert m.equals(this.getMethods().get(position));
		}

		for (int i = 0; i < this.getMethods().size() - 1; i++)
		{
			assert this.getNext(this.getMethods().get(i)).equals(this.getMethods().get(i + 1));
		}

		return true;
	}

	public Method getFirst()
	{
		return this.methods.getFirst();
	}

	public Method getLast()
	{
		return this.methods.getLast();
	}

	public List<Method> getMethods()
	{
		return this.methods;
	}

	public Method getNext(final Method method)
	{
		final Integer position = this.getPositions().get(method);

		assert position >= 0 && position < this.getMethods().size();

		if (position + 1 >= this.getMethods().size())
		{
			return null;
		}

		final Method next = this.getMethods().get(position + 1);
		return next;
	}

	private Map<Method, Integer> getPositions()
	{
		return this.positions;
	}

	public Iterator<Method> iterator()
	{
		return this.methods.iterator();
	}

	@Override
	public String toString()
	{
		return this.methods.toString();
	}
}
