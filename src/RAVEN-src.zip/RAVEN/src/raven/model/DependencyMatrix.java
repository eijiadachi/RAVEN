package raven.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.ITypeHierarchy;
import org.eclipse.jdt.core.JavaModelException;

import raven.analyzer.exception.AnalysisUncheckedException;
import raven.model.Rule.DependencyType;
import raven.model.Rule.RuleType;
import raven.util.EPLConstants;

@SuppressWarnings("rawtypes")
public class DependencyMatrix
{
	private static final Pattern REMAP_EXCEPTION_PAIR_PATTERN = Pattern.compile(EPLConstants.REMAP_EXCEPTION_PAIR_REGEX);

	private static final List<JavaType> GENERIC_EXCEPTIONS = new ArrayList<JavaType>();

	static
	{
		final JavaType exception = new JavaType("java.lang.Exception");
		final JavaType throwable = new JavaType("java.lang.Throwable");
		final JavaType error = new JavaType("java.lang.Error");

		GENERIC_EXCEPTIONS.add(exception);
		GENERIC_EXCEPTIONS.add(throwable);
		GENERIC_EXCEPTIONS.add(error);
	}

	private static final Map<String, IType[]> supertypesCache = new HashMap<>();

	private final Map<Method, Map<DependencyType, Set>> matrix;

	private final CallChain callChain;

	private final SimilarityMatrix similarityMatrix;

	private final CallGraph callGraph;

	private final String expectedException;

	private final IJavaProject javaProject;

	private final Map<Method, Integer> additions;

	private final Map<Method, Integer> removals;

	public DependencyMatrix(final CallChain callChain, final CallGraph callGraph, final List<Compartment> compartments, final IJavaProject javaProject,
			final String expectedException)
	{
		this.callChain = callChain;
		this.callGraph = callGraph;
		this.similarityMatrix = new SimilarityMatrix(callGraph);
		this.expectedException = expectedException;
		this.javaProject = javaProject;
		this.additions = new HashMap<Method, Integer>();
		this.removals = new HashMap<Method, Integer>();

		//BEGIN build_matrix
		this.matrix = new HashMap<Method, Map<DependencyType, Set>>();

		for (final Method method : callChain.getMethods())
		{
			final Map<DependencyType, Set> line = new HashMap<DependencyType, Set>();
			for (final DependencyType type : DependencyType.values())
			{
				final Set cell = new TreeSet();
				line.put(type, cell);
			}

			this.matrix.put(method, line);
		}
		//END build_matrix

		//BEGIN fill_matrix
		final List<Method> allMethods = this.callChain.getMethods();

		this.fillMatrix(allMethods);

		this.fillSimilarMethods(allMethods);

		this.fillRules(allMethods, RuleType.MayOnly);

		this.fillRules(allMethods, RuleType.Must);

		this.fillCannotRules(allMethods);

		this.fillOnlyMayRules(allMethods, compartments);

		//END fill_matrix
	}

	private void addition(Method method)
	{
		Integer adds = this.additions.get(method);
		if (adds == null)
		{
			adds = Integer.valueOf(1);
		}
		else
		{
			++adds;
		}
		this.additions.put(method, adds);
	}

	@SuppressWarnings("unchecked")
	private void fillCannotRules(final List<Method> allMethods)
	{
		for (final Method method : allMethods)
		{
			final Compartment compartment = method.getCompartment();
			if (compartment == null)
			{
				continue;
			}

			final List<Rule> rules = compartment.getRules();
			if (rules == null || rules.isEmpty())
			{
				continue;
			}

			for (final Rule rule : rules)
			{
				if (!RuleType.Cannot.equals(rule.getRuleType()))
				{
					continue;
				}

				final DependencyType depType = rule.getDependencyType();
				final Set cell = this.getCell(method, depType);
				final Set clone = new HashSet(cell);
				final List<String> exceptionExpressions = rule.getExceptionExpressions();
				for (final String exceptionExpression : exceptionExpressions)
				{
					final Iterator iterator = clone.iterator();
					while (iterator.hasNext())
					{
						final Object obj = iterator.next();
						if (depType.equals(DependencyType.Remap))
						{
							//FIXME Improve
							final String fromExp = exceptionExpression.split("\\s")[1];
							final String toExp = exceptionExpression.split("\\s")[3];

							final ExceptionPair pair = (ExceptionPair) obj;
							final String from = pair.getFrom().getFullyQualifiedName();
							final String to = pair.getTo().getFullyQualifiedName();

							if (from.matches(fromExp) && to.matches(toExp))
							{
								final boolean removed = cell.remove(pair);
								if (removed)
								{
									this.removal(method);
								}
							}
						}
						else
						{
							final JavaType exception = (JavaType) obj;
							if (exception.getFullyQualifiedName().matches(exceptionExpression))
							{
								final boolean removed = cell.remove(exception);
								if (removed)
								{
									this.removal(method);
								}
							}
						}
					}
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void fillMatrix(List<Method> allMethods)
	{
		for (Method m : allMethods)
		{
			m.getExceptionsHandled().stream().forEach(e -> this.getCell(m, DependencyType.Handle).add(e));
			m.getExceptionsPropagated().stream().forEach(e -> this.getCell(m, DependencyType.Propagate).add(e));
			m.getExceptionsRaised().stream().forEach(e -> this.getCell(m, DependencyType.Raise).add(e));
			m.getExceptionsRemapped().stream().forEach(e -> this.getCell(m, DependencyType.Remap).add(e));
			m.getExceptionsRethrown().stream().forEach(e -> this.getCell(m, DependencyType.Rethrow).add(e));
		}

	}

	@SuppressWarnings("unchecked")
	private void fillOnlyMayRules(final List<Method> allMethods, final List<Compartment> compartments)
	{
		for (final Compartment compartment : compartments)
		{
			final List<Rule> rules = compartment.getRules();
			if (rules == null || rules.isEmpty())
			{
				continue;
			}

			final List<Method> methodsInCompartment = compartment.getMethods();
			if (methodsInCompartment == null)
			{
				continue;
			}

			// Other Methods := all methods - methods in compartment
			final Set<Method> otherMethods = new HashSet<>(this.matrix.keySet());
			otherMethods.removeAll(methodsInCompartment);

			for (final Rule rule : rules)
			{
				if (!RuleType.OnlyMay.equals(rule.getRuleType()))
				{
					continue;
				}

				final DependencyType depType = rule.getDependencyType();

				final List<String> exceptionExpressions = rule.getExceptionExpressions();

				// If only compartment may relate to exception, then remove this exception from other methods
				// If only compartment may relate to exception, then add this exception to methods in compartment
				if (depType.equals(DependencyType.Remap))
				{
					for (final String exceptionExpression : exceptionExpressions)
					{
						final Matcher matcher = REMAP_EXCEPTION_PAIR_PATTERN.matcher(exceptionExpression);
						if (matcher.find())
						{
							final String from = matcher.group(1).replace("\\.", ".");
							final String to = matcher.group(2).replace("\\.", ".");
							final ExceptionPair pair = new ExceptionPair(new JavaType(from), new JavaType(to));

							for (final Method otherMethod : otherMethods)
							{
								final Set otherCell = this.getCell(otherMethod, depType);
								final boolean removed = otherCell.remove(pair);
								if (removed)
								{
									this.removal(otherMethod);
								}
							}

							for (final Method methodInCompartment : methodsInCompartment)
							{
								final Set cell = this.getCell(methodInCompartment, depType);

								final boolean added = cell.add(pair);
								if (added)
								{
									this.addition(methodInCompartment);
								}

								assert cell.stream().allMatch(e -> e instanceof ExceptionPair) : String.format(
										"Invalid state: element in %s cell is not of type ExceptionPair.", depType);
							}
						}
					}
				}
				else
				{
					for (final String exceptionExpression : exceptionExpressions)
					{
						final JavaType exception = new JavaType(exceptionExpression.replace("\\.", "."));
						for (final Method otherMethod : otherMethods)
						{
							final Set otherCell = this.getCell(otherMethod, depType);
							final boolean removed = otherCell.remove(exception);
							if (removed)
							{
								this.removal(otherMethod);
							}
						}

						for (final Method methodInCompartment : methodsInCompartment)
						{
							final Set cell = this.getCell(methodInCompartment, depType);

							final boolean added = cell.add(exception);
							if (added)
							{
								this.addition(methodInCompartment);
							}

							assert cell.stream().allMatch(e -> e instanceof JavaType) : String.format(
									"Invalid state: element in %s cell is not of type JavaType.", depType);
						}
					}
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void fillRules(final List<Method> allMethods, final RuleType ruleType)
	{
		for (final Method method : allMethods)
		{
			final Compartment compartment = method.getCompartment();
			if (compartment == null)
			{
				continue;
			}
			final List<Rule> rules = compartment.getRules();
			if (rules == null || rules.isEmpty())
			{
				continue;
			}

			for (final Rule rule : rules)
			{
				if (!ruleType.equals(rule.getRuleType()))
				{
					continue;
				}
				final DependencyType depType = rule.getDependencyType();
				final Set cell = this.getCell(method, depType);

				final List<String> exceptionExpressions = rule.getExceptionExpressions();

				if (depType.equals(DependencyType.Remap))
				{
					for (final String exceptionExpression : exceptionExpressions)
					{
						final Matcher matcher = REMAP_EXCEPTION_PAIR_PATTERN.matcher(exceptionExpression);
						if (matcher.find())
						{
							final String from = matcher.group(1).replace("\\.", ".");
							final String to = matcher.group(2).replace("\\.", ".");
							final ExceptionPair pair = new ExceptionPair(new JavaType(from), new JavaType(to));
							final boolean added = cell.add(pair);
							if (added)
							{
								this.addition(method);
							}
						}
					}

					assert cell.stream().allMatch(e -> e instanceof ExceptionPair) : String.format(
							"Invalid state: element in %s cell is not of type ExceptionPair.", depType);
				}
				else
				{
					for (final String exceptionExpression : exceptionExpressions)
					{
						final JavaType exception = new JavaType(exceptionExpression.replace("\\.", "."));
						final boolean added = cell.add(exception);
						if (added)
						{
							this.addition(method);
						}
					}

					assert cell.stream().allMatch(e -> e instanceof JavaType) : String.format("Invalid state: element in %s cell is not of type JavaType.",
							depType);
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void fillSimilarMethods(final List<Method> allMethods)
	{
		for (final Method method : allMethods)
		{
			for (final DependencyType depType : DependencyType.values())
			{
				final Set cell = this.getCell(method, depType);

				if (!cell.isEmpty())
				{
					continue;
				}

				// Adds the exceptions of the own method
				final List<Method> ownMethod = Arrays.asList(method);

				final Set ownExceptions = this.getAllExceptions(ownMethod, depType);

				cell.addAll(ownExceptions);

				// Adds the exceptions from similar methods
				final List<Method> similarMethods = this.similarityMatrix.getSimilarMethods(method);

				final Set allExceptions = this.getAllExceptions(similarMethods, depType);

				cell.addAll(allExceptions);
			}
		}
	}

	public Map<Method, Integer> getAdditions()
	{
		return additions;
	}

	public Integer getAdditions(Method method)
	{
		Integer i = this.additions.get(method);
		if (i == null)
		{
			return 0;
		}
		return i;
	}

	@SuppressWarnings("unchecked")
	private Set getAllExceptions(final List<Method> methods, final DependencyType depType)
	{
		final Set allExceptions = new TreeSet();

		for (final Method method : methods)
		{
			switch (depType)
			{
				case Handle:
					allExceptions.addAll(method.getExceptionsHandled());
					break;
				case Propagate:
					allExceptions.addAll(method.getExceptionsPropagated());
					break;
				case Raise:
					allExceptions.addAll(method.getExceptionsRaised());
					break;
				case Remap:
					allExceptions.addAll(method.getExceptionsRemapped());
					break;
				case Rethrow:
					allExceptions.addAll(method.getExceptionsRethrown());
					break;
				default:
					throw new IllegalStateException(String.format("Illegal Dependency Type used: %s.", depType));
			}
		}
		return allExceptions;
	}

	@SuppressWarnings("unchecked")
	public Set getCell(final Method method, final DependencyType depType)
	{
		final Map<DependencyType, Set> line = this.matrix.get(method);
		if (line == null)
		{
			return new HashSet();
		}

		final Set set = line.get(depType);

		if (set != null && !set.isEmpty())
		{
			if (depType.equals(DependencyType.Remap))
			{
				final boolean allMatch = set.stream().allMatch(e -> e instanceof ExceptionPair);
				if (!allMatch)
				{
					throw new AnalysisUncheckedException(String.format("Invalid structure for %s %s \n%s", method, depType, set));
				}
			}
			else
			{
				final boolean allMatch = set.stream().allMatch(e -> e instanceof JavaType);
				if (!allMatch)
				{
					throw new AnalysisUncheckedException(String.format("Invalid structure for %s %s \n%s", method, depType, set));
				}
			}
		}

		return set;
	}

	public void getLines()
	{
		final Set<Entry<Method, Map<DependencyType, Set>>> entrySet = this.matrix.entrySet();
		for (final Entry<Method, Map<DependencyType, Set>> entry : entrySet)
		{
			final Method key = entry.getKey();
			final Map<DependencyType, Set> value = entry.getValue();
			final Set<Entry<DependencyType, Set>> entrySet2 = value.entrySet();
			for (final Entry<DependencyType, Set> entry2 : entrySet2)
			{
				final DependencyType key2 = entry2.getKey();
				final Set value2 = entry2.getValue();
				System.out.println(String.format("%s %s %s", key, key2, value2));
			}
		}
	}

	public Map<Method, Map<DependencyType, Set>> getMatrix()
	{
		return this.matrix;
	}

	private List<DependencyType> getNext(final DependencyType type)
	{
		switch (type)
		{
			case Raise:
			case Propagate:
			case Remap:
			case Rethrow:
				return Arrays.asList(DependencyType.Propagate, DependencyType.Handle, DependencyType.Remap, DependencyType.Rethrow);

			case Handle:
				return Collections.emptyList();

			default:
				throw new IllegalArgumentException("Unknown enum type " + type);
		}
	}

	public List<Recommendation> getRecommendations()
	{
		final List<Recommendation> result = new ArrayList<>();
		final Recommendation solution = new Recommendation();
		final DependencyType raise = DependencyType.Raise;

		final List<Method> methods = this.callChain.getMethods();
		for (final Method method : methods)
		{
			final Set canRaise = this.matrix.get(method).get(raise);
			for (final Object raisableException : canRaise)
			{
				if (GENERIC_EXCEPTIONS.contains(raisableException))
				{
					continue;
				}

				final RecommendationElement element = new RecommendationElement(method, raise, raisableException);

				solution.addRecommendationElement(element);

				final List<DependencyType> nextTypes = this.getNext(raise);

				final Method nextMethod = this.callChain.getNext(method);

				if (nextMethod != null)
				{
					this.getRecommendationsRecursively(result, solution, nextMethod, nextTypes);
				}
			}
			solution.clear();
		}

		result.forEach(e -> e.computeChangeImpact(this.callGraph));

		return result;
	}

	private void getRecommendationsRecursively(final List<Recommendation> result, final Recommendation solution, final Method method,
			final List<DependencyType> types)
	{
		if (!this.isValid(solution))
		{
			solution.pop();
			return;
		}

		if (this.isFinalSolution(solution))
		{
			final boolean containsExpectedException = solution.getRecommendationElements().stream()
					.anyMatch(e -> e.getException().toString().contains(this.expectedException));

			// Only add it to the global solution array if contains expected exception
			if (containsExpectedException)
			{
				final Recommendation solutionClone = solution.clone();
				result.add(solutionClone);
			}
			solution.pop();
		}
		else
		{
			for (final DependencyType type : types)
			{
				final Set possibleExceptions = this.matrix.get(method).get(type);

				for (final Object exception : possibleExceptions)
				{
					final RecommendationElement element = new RecommendationElement(method, type, exception);
					solution.addRecommendationElement(element);
					final Method nextMethod = this.callChain.getNext(method);
					final List<DependencyType> nextTypes = this.getNext(type);
					this.getRecommendationsRecursively(result, solution, nextMethod, nextTypes);
				}
			}
			solution.pop();
		}
	}

	public Map<Method, Integer> getRemovals()
	{
		return removals;
	}

	public Integer getRemovals(Method method)
	{
		Integer i = this.removals.get(method);
		if (i == null)
		{
			return 0;
		}
		return i;
	}

	private boolean isFinalSolution(final Recommendation solution)
	{
		final List<RecommendationElement> recommendationElements = solution.getRecommendationElements();
		final RecommendationElement first = recommendationElements.get(0);
		final RecommendationElement last = recommendationElements.get(recommendationElements.size() - 1);
		return first.getDependencyType().equals(DependencyType.Raise) && last.getDependencyType().equals(DependencyType.Handle);
	}

	/**
	 * Checks if class1 is directly or transitively superclass of class2.
	 */
	private boolean isSuperclass(final String className1, final String className2)
	{
		IType[] superTypes = supertypesCache.get(className2);
		if (superTypes == null)
		{
			try
			{
				final IType type = this.javaProject.findType(className2, new NullProgressMonitor());
				if (type == null)
				{
					System.err.println("Could not find superclass for " + className2);
					return false;
				}
				final ITypeHierarchy typeHierarchy = type.newTypeHierarchy(new NullProgressMonitor());
				superTypes = typeHierarchy.getAllSupertypes(type);
				supertypesCache.put(className2, superTypes);
			}
			catch (final JavaModelException e)
			{
				System.err.println("[Dependency Matrix] Error in isSuperClass: " + e.getMessage());
				return false;
			}
		}

		final boolean isSuperType = Arrays.asList(superTypes).stream().anyMatch(element -> element.getFullyQualifiedName().equals(className1));
		return isSuperType;
	}

	private boolean isValid(final Recommendation solution)
	{
		final List<RecommendationElement> recommendationElements = solution.getRecommendationElements();
		for (int i = 0; i < recommendationElements.size() - 1; i++)
		{
			final RecommendationElement current = recommendationElements.get(i);
			final RecommendationElement next = recommendationElements.get(i + 1);

			if (DependencyType.Remap.equals(current.getDependencyType()))
			{
				final ExceptionPair currentPair = (ExceptionPair) current.getException();
				final JavaType to = currentPair.getTo();

				// This is the case of two consecutive remaps
				if (DependencyType.Remap.equals(next.getDependencyType()))
				{
					final ExceptionPair nextPair = (ExceptionPair) next.getException();
					final JavaType from = nextPair.getFrom();
					if (!to.equals(from) && !this.isSuperclass(from.getFullyQualifiedName(), to.getFullyQualifiedName()))
					{
						return false;
					}
				}
				else
				{
					if (!to.equals(next.getException()))
					{
						return false;
					}
				}
			}
			else if (DependencyType.Remap.equals(next.getDependencyType()))
			{
				final ExceptionPair pair = (ExceptionPair) next.getException();
				final JavaType from = pair.getFrom();

				if (!from.equals(current.getException()) && !this.isSuperclass(from.toString(), ((JavaType) current.getException()).getFullyQualifiedName()))
				{
					return false;
				}
			}
			else
			{
				final JavaType currentException = (JavaType) current.getException();
				final JavaType nextException = (JavaType) next.getException();
				if (!currentException.equals(nextException))
				{
					return false;
				}
			}
		}

		final RecommendationElement lastElement = solution.getRecommendationElements().get(solution.size() - 1);
		final Method lastMethod = lastElement.getMethod();

		final Method nextMethod = this.callChain.getNext(lastMethod);
		if (null == nextMethod && !DependencyType.Handle.equals(lastElement.getDependencyType()))
		{
			return false;
		}

		return true;
	}

	private void removal(Method method)
	{
		Integer removs = this.removals.get(method);
		if (removs == null)
		{
			removs = Integer.valueOf(1);
		}
		else
		{
			++removs;
		}
		this.removals.put(method, removs);
	}
}
