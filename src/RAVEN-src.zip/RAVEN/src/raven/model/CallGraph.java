package raven.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Stack;

public class CallGraph implements Serializable
{
	/**
	 *
	 */
	private static final long serialVersionUID = 5107695124112605702L;

	private static final String DELIMITER = "<METHOD_DELIMITHER>";

	private final Map<String, Method> nodesMap;

	private final Map<Method, Set<Method>> successorsMap;

	private final Map<Method, Set<Method>> predecessorsMap;

	private final List<Method> nodes;

	public CallGraph()
	{
		this.nodesMap = new HashMap<String, Method>();
		this.successorsMap = new HashMap<Method, Set<Method>>();
		this.predecessorsMap = new HashMap<Method, Set<Method>>();
		this.nodes = new ArrayList<Method>();
	}

	public void addEdge(final Method source, final Method dest)
	{
		assert this.getNodes().contains(source) : "Node should be inserted in the graph before adding an edge: " + source;
		assert this.getNodes().contains(dest) : "Node should be inserted in the graph before adding an edge: " + dest;

		Set<Method> successors = this.getSuccessorsMap().get(source);
		if (null == successors)
		{
			successors = new LinkedHashSet<Method>();
			this.getSuccessorsMap().put(source, successors);
		}
		successors.add(dest);

		Set<Method> predecessors = this.getPredecessorsMap().get(dest);
		if (null == predecessors)
		{
			predecessors = new LinkedHashSet<Method>();
			this.getPredecessorsMap().put(dest, predecessors);
		}
		predecessors.add(source);
	}

	public void addNode(final Method method)
	{
		assert !this.getNodes().contains(method) : "Node already exists in the graph: " + method;

		final String fqNameWithParameters = method.getFullyQualifiedNameWithParameters();

		this.getNodesMap().put(fqNameWithParameters, method);
		this.getNodes().add(method);

		assert this.getNodesMap().containsValue(method);
		assert this.getNodes().contains(method);
		assert this.getNodesMap().get(fqNameWithParameters) == this.getMethod(fqNameWithParameters);
		assert this.getNodesMap().containsValue(this.getNodesMap().get(fqNameWithParameters));
	}

	private List<CallChain> buildCallChains(final Method method)
	{
		final List<List<Method>> predecessors = this.buildPredecessors(method);
		final List<List<Method>> successors = this.buildSuccessors(method);

		final List<CallChain> result = new ArrayList<CallChain>();
		for (final List<Method> pred : predecessors)
		{
			pred.remove(method);
			for (final List<Method> suc : successors)
			{
				suc.remove(method);
				Collections.reverse(suc);

				final CallChain callChain = new CallChain();

				callChain.addAll(suc);
				callChain.add(method);
				callChain.addAll(pred);

				result.add(callChain);

				assert callChain.check();
			}

		}

		return result;
	}

	private List<List<Method>> buildPredecessors(final Method method)
	{
		// depth-first search using an explicit stack
		final Stack<String> stack = new Stack<>();

		stack.push(method.toString());

		final List<List<Method>> result = new ArrayList<>();
		final Stack<Method> chain = new Stack<>();
		while (!stack.isEmpty())
		{
			final String currentStr = stack.pop();

			// the adjacency list was exhausted
			if (currentStr.equals(DELIMITER))
			{
				chain.pop();
				continue;
			}

			final Method current = this.getMethod(currentStr);
			if (chain.contains(current))
			{
				// avoids infinite loops caused by recursive calls
				continue;
			}
			chain.push(current);

			final Set<Method> predecessors = this.getPredecessors(current);

			//If exists adjacency list
			if (!predecessors.isEmpty())
			{
				stack.push(DELIMITER);
				for (final Method m : predecessors)
				{
					final String mStr = m.toString();
					if (!currentStr.equals(mStr))
					{
						stack.push(mStr);
					}
				}
			}
			else
			{
				final ArrayList<Method> copy = new ArrayList<Method>(chain);
				result.add(copy);
				chain.pop();
			}
		}

		return result;
	}

	private List<List<Method>> buildSuccessors(final Method method)
	{
		// depth-first search using an explicit stack
		final Stack<String> stack = new Stack<>();

		stack.push(method.toString());

		final List<List<Method>> result = new ArrayList<>();
		final Stack<Method> chain = new Stack<>();
		while (!stack.isEmpty())
		{
			final String currentStr = stack.pop();

			// the adjacency list was exhausted
			if (currentStr.equals(DELIMITER))
			{
				chain.pop();
				continue;
			}

			final Method current = this.getMethod(currentStr);
			if (chain.contains(current))
			{
				// avoids infinite loops caused by recursive calls
				continue;
			}
			chain.push(current);

			final Set<Method> successors = this.getSuccessors(current);

			//If exists adjacency list
			if (!successors.isEmpty())
			{
				stack.push(DELIMITER);
				for (final Method m : successors)
				{
					final String mStr = m.toString();
					if (!currentStr.equals(mStr))
					{
						stack.push(mStr);
					}
				}
			}
			else
			{
				final ArrayList<Method> copy = new ArrayList<Method>(chain);
				result.add(copy);
				chain.pop();
			}
		}

		return result;
	}

	public boolean check()
	{
		// Checks getMethod (part of checking the nodes)
		for (final Method method : this.getNodes())
		{
			final Method m = this.getMethod(method.getFullyQualifiedNameWithParameters());
			assert m.equals(method);
			assert this.getNodesMap().containsValue(m);
		}

		// Checks nodeMap (part of checking the nodes)
		for (final Entry<String, Method> entry : this.getNodesMap().entrySet())
		{
			final String fqNameWithParameters = entry.getKey();
			final Method m = entry.getValue();

			assert m.equals(this.getMethod(fqNameWithParameters));
		}

		// Checks successorsMap (part of checking the edges)
		for (final Entry<Method, Set<Method>> entry : this.getSuccessorsMap().entrySet())
		{
			assert this.getNodes().contains(entry.getKey());

			for (final Method m : entry.getValue())
			{
				assert this.getNodes().contains(m);
			}
		}

		// Checks successorsMap (part of checking the edges)
		for (final Entry<Method, Set<Method>> entry : this.getPredecessorsMap().entrySet())
		{
			assert this.getNodes().contains(entry.getKey());

			for (final Method m : entry.getValue())
			{
				assert this.getNodes().contains(m);
			}
		}

		return true;
	}

	public List<CallChain> getCallChains(final Method method)
	{
		final List<CallChain> callChains = this.buildCallChains(method);
		return callChains;
	}

	public List<CallChain> getCallChains(final String methodName)
	{
		final Method method = this.getMethod(methodName);
		final List<CallChain> callChains = this.getCallChains(method);
		return callChains;
	}

	public Method getMethod(final String methodName)
	{
		final Method method = this.getNodesMap().get(methodName);
		if (method != null)
		{
			assert method.getFullyQualifiedNameWithParameters().equals(methodName);
			assert this.getNodes().contains(method);
		}
		return method;
	}

	public List<Method> getNodes()
	{
		return this.nodes;
	}

	private Map<String, Method> getNodesMap()
	{
		return this.nodesMap;
	}

	private Set<Method> getPredecessors(final Method k)
	{
		final Set<Method> set = this.getPredecessorsMap().get(k);
		if (set != null)
		{
			return set;
		}
		return Collections.emptySet();
	}

	private Map<Method, Set<Method>> getPredecessorsMap()
	{
		return this.predecessorsMap;
	}

	private Set<Method> getSuccessors(final Method k)
	{
		final Set<Method> set = this.getSuccessorsMap().get(k);
		if (set != null)
		{
			return set;
		}
		return Collections.emptySet();
	}

	private Map<Method, Set<Method>> getSuccessorsMap()
	{
		return this.successorsMap;
	}

	@Override
	public String toString()
	{
		final StringBuilder builder = new StringBuilder();

		final Set<Entry<Method, Set<Method>>> entrySet = this.getSuccessorsMap().entrySet();
		for (final Entry<Method, Set<Method>> entry : entrySet)
		{
			final Method key = entry.getKey();
			final Set<Method> value = entry.getValue();
			final String str = String.format("%s -> %s\n", key, value);
			builder.append(str);
		}

		return builder.toString();
	}

}
